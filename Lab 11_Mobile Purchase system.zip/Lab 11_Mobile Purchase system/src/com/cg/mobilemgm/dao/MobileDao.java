package com.cg.mobilemgm.dao;

import java.util.ArrayList;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;


public interface MobileDao 
{
	public int addMobPur(PurchaseDetails pur, Mobiles mob) throws MobileException;
	public long getPurchaseId() throws MobileException;	
	public ArrayList<Integer> getAllMobileId() throws MobileException;
	public int getMobQuan(Mobiles mob) throws MobileException;
	public ArrayList<Mobiles> getAllMob() throws MobileException;
	
	public int deleteMobDetail(int mobId)throws MobileException;
	
	public ArrayList<Mobiles> searchMob(float maxRange, float minRange) 
			throws MobileException;
	public int updateMobile(Mobiles mob) throws MobileException;

}
