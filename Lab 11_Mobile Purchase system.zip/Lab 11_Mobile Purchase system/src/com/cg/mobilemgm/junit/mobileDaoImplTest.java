package com.cg.mobilemgm.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.dao.MobileDao;
import com.cg.mobilemgm.dao.MobileDaoImpl;
import com.cg.mobilemgm.exception.MobileException;

public class mobileDaoImplTest
{
	static Mobiles mob=null;
	static MobileDao mobdao=null;
	static PurchaseDetails purd=null;
	
	@BeforeClass
	public static void beforeClass() throws MobileException
	{
		long millis=System.currentTimeMillis();  
		java.sql.Date datee=new java.sql.Date(millis);
		mobdao=new MobileDaoImpl();
		mob=new Mobiles(1001,"Nokia Lumia 520",8000,2);
		purd=new PurchaseDetails(mobdao.getPurchaseId(),"Jyoti",
				"jyoi@gmail.com",datee,"9865325263",mob);
	}
	
	@Test
	public void testAddPur() throws MobileException
	{
		Assert.assertEquals(1, mobdao.addMobPur(purd, mob));
	}

}
